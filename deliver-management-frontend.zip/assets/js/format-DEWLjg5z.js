import{am as t}from"./element-plus-CPLraCBR.js";function f(r,m="YYYY-MM-DD HH:mm:ss"){return r?t(r).format(m):"-"}export{f};
